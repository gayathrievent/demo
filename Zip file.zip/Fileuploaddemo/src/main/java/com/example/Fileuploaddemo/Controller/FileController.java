package com.example.Fileuploaddemo.Controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.apache.tomcat.util.file.ConfigurationSource.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;


@RestController
@RequestMapping("/files")
public class FileController {
	
	private final Path uploadDir =Paths.get("uploads");
	
	public FileController() throws IOException {
		//Create directory if not exists
		if(!Files.exists(uploadDir)) {
			Files.createDirectories(uploadDir);
		}
	}
	
	@PostMapping("/upload")
	public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file) throws IOException
	{
		Path filepath=uploadDir.resolve(file.getOriginalFilename());
		Files.copy(file.getInputStream(), filepath, StandardCopyOption.REPLACE_EXISTING);
		return ResponseEntity.ok("File uploaded Successfully: " + file.getOriginalFilename());
	}
	
	
	@GetMapping("/download/{filename:.+}")
	public ResponseEntity<UrlResource> downloadFile(@PathVariable String filename) throws IOException {
		Path filePath = uploadDir.resolve(filename).normalize();
	    UrlResource resource = new UrlResource(filePath.toUri());

	    if (!resource.exists()) {
	        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
	    }

	    String contentType = Files.probeContentType(filePath);
	    if (contentType == null) {
	        contentType = "application/octet-stream";
	    }

	    return ResponseEntity.ok()
	            .contentType(MediaType.parseMediaType(contentType))
	            .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
	            .body(resource);

	}
}
