package com.example.Fileuploaddemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileuploaddemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
